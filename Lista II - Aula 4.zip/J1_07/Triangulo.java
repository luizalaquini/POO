public class Triangulo {
    Ponto p1 = new Ponto();
    Ponto p2 = new Ponto();
    Ponto p3 = new Ponto();
}
