public class Ponto {
    double x;
    double y;
}

